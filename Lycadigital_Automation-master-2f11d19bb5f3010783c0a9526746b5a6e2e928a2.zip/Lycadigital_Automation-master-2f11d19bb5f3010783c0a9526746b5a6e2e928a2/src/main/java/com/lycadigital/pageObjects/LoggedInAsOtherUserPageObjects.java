package com.lycadigital.pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.lycadigital.genericUtils.ExtentReports.ExtentTestManager;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class LoggedInAsOtherUserPageObjects {
	
		
		public LoggedInAsOtherUserPageObjects(AppiumDriver driver) {
			PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		}
		
		/**************************************************************************
		 * 		Initializing Page Objects for LoggedInAsOtherUserPageObjects
		 * 
		 * ************************************************************************/
		
		@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id = 'com.lycadigital.lycamobile:id/btn_nl_bundles']")
		public static WebElement bundles;
		
		@AndroidFindBy(id = "com.lycadigital.lycamobile:id/btn_nl_topup")
		public static WebElement topUp;
		
		@AndroidFindBy(id = "com.lycadigital.lycamobile:id/btn_nl_callrates")
		public static WebElement checkRates;
		
		@AndroidFindBy(id = "com.lycadigital.lycamobile:id/btn_nl_got_sim")
		public static WebElement loginOrRegister;
	
		
		
		/**************************************************************************
		 * 		Methods for LoggedInAsOtherUserPageObjects
		 * 
		 * ************************************************************************/
		
		public static void tapOnBundles() {
			bundles.click();
			ExtentTestManager.getTest().log(LogStatus.PASS, "Clicked on 'Bundles' button");
		}
		
		public static void tapOnTopUp() {
			topUp.click();
			ExtentTestManager.getTest().log(LogStatus.PASS, "Clicked on 'Top Up' button");
		}
		
		public static void tapOnCheckRates() {
			checkRates.click();
			ExtentTestManager.getTest().log(LogStatus.PASS, "Clicked on 'Check Rates' button");
		}
		
		public static void tapOnLoginOrRegister() {
			loginOrRegister.click();
			ExtentTestManager.getTest().log(LogStatus.PASS, "Clicked on 'Login or Register' button");
		
	}

}
