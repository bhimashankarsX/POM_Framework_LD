package com.lycadigital.pageObjects;

import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.w3c.dom.DOMException;
import org.xml.sax.SAXException;

import com.lycadigital.genericUtils.ExtentReports.ExtentTestManager;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class GetStartedPageObjects {
	


	public GetStartedPageObjects(AppiumDriver driver) throws DOMException, SAXException, IOException, ParserConfigurationException, InterruptedException {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	
	}
	
	
	/**************************************************************************
	 * 		Initializing Page Objects for GetStartedPageObjects
	 * 
	 * ************************************************************************/
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idGetStartedBtn")
	public static WebElement getStartedButton;
	
	
	
	/**************************************************************************
	 * 		Methods for GetStartedPageObjects
	 * 
	 * ************************************************************************/
	
	
	public static void tapOnGetStarted() {
		getStartedButton.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Clicked on 'Get Started' button");
	  }
	
 
}
