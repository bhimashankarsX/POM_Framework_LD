package com.lycadigital.pageObjects;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.w3c.dom.DOMException;
import org.xml.sax.SAXException;

import com.lycadigital.genericUtils.ExtentReports.ExtentTestManager;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class UKTopUpPageObjects {
	
	public UKTopUpPageObjects(AppiumDriver driver) throws DOMException, SAXException, IOException, ParserConfigurationException, InterruptedException {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	
	}
	
	
	/**************************************************************************
	 * 		Initializing Page Objects for UKTopUpPageObjects
	 * 
	 * ************************************************************************/
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = '£10']")
	public static WebElement selectTopUpAmount;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idAddBundleBtn")
	public static WebElement addBundleButton;
	
	
	

	
	/**************************************************************************
	 * 		Methods for UKTopUpPageObjects
	 * 
	 * ************************************************************************/
	
	public static void selectTopUpValue() {
		selectTopUpAmount.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Selected TOP UP amount of £10");
	}
	
	public static void addBundle() {
		addBundleButton.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Clicked on 'Select A Bundle' button");
	}
}
