package com.lycadigital.pageObjects;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.w3c.dom.DOMException;
import org.xml.sax.SAXException;

import com.lycadigital.genericUtils.XMLReader;
import com.lycadigital.genericUtils.ExtentReports.ExtentTestManager;
import com.lycadigital.genericUtils.XMLReader.readerCases;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class BillingAddressPageObjects {
	
	public BillingAddressPageObjects(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	private static String HOUSE;
	private static String STREET;
	private static String CITY;
	private static String COUNTY;
	private static String COUNTRY;
	private static String POSTAL_CODE;
	private static String EMAIL;
	
	
	/**************************************************************************
	 * 		Initializing Page Objects for UKBundlePageObjects
	 * 
	 * ************************************************************************/
	

	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/et_payadd_houseno")
	public static WebElement house;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/et_payadd_street")
	public static WebElement street;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/et_payadd_city")
	public static WebElement city;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/et_payadd_county")
	public static WebElement county;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/et_payadd_country")
	public static WebElement country;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/et_payadd_postcode")
	public static WebElement postalCode;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/et_payadd_email")
	public static WebElement email;

	

	
	
	
	/**************************************************************************
	 * 		Methods for UKBundlePageObjects
	 * @throws ParserConfigurationException 
	 * @throws IOException 
	 * @throws SAXException 
	 * @throws DOMException 
	 * 
	 * ************************************************************************/
	
	public static void fillPaymentForm() throws DOMException, SAXException, IOException, ParserConfigurationException {
		
		house.sendKeys(getHOUSE());
		street.sendKeys(getSTREET());
		city.sendKeys(getCITY());
		county.sendKeys(getCOUNTY());
		country.sendKeys(getCOUNTRY());
		postalCode.sendKeys(getPOSTAL_CODE());
		email.sendKeys(getEMAIL());
		
		ExtentTestManager.getTest().log(LogStatus.PASS, "Filled Payment Invoice details");
	}
	
	
	public static String getHOUSE() throws DOMException, SAXException, IOException, ParserConfigurationException {
		HOUSE = XMLReader.reader(readerCases.TEST_DATA).getElementsByTagName("house").item(0).getTextContent();
		return HOUSE;
	}

	public static String getSTREET() throws DOMException, SAXException, IOException, ParserConfigurationException {
		STREET = XMLReader.reader(readerCases.TEST_DATA).getElementsByTagName("street").item(0).getTextContent();
		return STREET;
	}

	public static String getCITY() throws DOMException, SAXException, IOException, ParserConfigurationException {
		CITY = XMLReader.reader(readerCases.TEST_DATA).getElementsByTagName("city").item(0).getTextContent();
		return CITY;
	}

	public static String getCOUNTY() throws DOMException, SAXException, IOException, ParserConfigurationException {
		COUNTY = XMLReader.reader(readerCases.TEST_DATA).getElementsByTagName("county").item(0).getTextContent();
		return COUNTY;
	}

	public static String getCOUNTRY() throws DOMException, SAXException, IOException, ParserConfigurationException {
		COUNTRY = XMLReader.reader(readerCases.TEST_DATA).getElementsByTagName("country").item(0).getTextContent();
		return COUNTRY;
	}

	public static String getPOSTAL_CODE() throws DOMException, SAXException, IOException, ParserConfigurationException {
		POSTAL_CODE = XMLReader.reader(readerCases.TEST_DATA).getElementsByTagName("postalCode").item(0).getTextContent();
		return POSTAL_CODE;
	}

	public static String getEMAIL() throws DOMException, SAXException, IOException, ParserConfigurationException {
		EMAIL = XMLReader.reader(readerCases.TEST_DATA).getElementsByTagName("email").item(0).getTextContent();
		return EMAIL;
	}
}
