package com.lycadigital.pageObjects;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.w3c.dom.DOMException;
import org.xml.sax.SAXException;

import com.lycadigital.driverengine.InstantiateAppium;
import com.lycadigital.genericUtils.XMLReader;
import com.lycadigital.genericUtils.XMLReader.readerCases;
import com.lycadigital.genericUtils.ExtentReports.ExtentTestManager;
import com.lycadigital.testrunner.TestRunner;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class LoginPageObjects {
	
	public LoginPageObjects(AppiumDriver driver)  {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	/**************************************************************************
	 * 		Initializing Page Objects for LoginPageObjects
	 * 
	 * ************************************************************************/
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idSpinnerSelectCountry")
	protected static WebElement selectCountryDropDown;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idEditTextMobileNumber")
	protected static WebElement phoneNumberEditText;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idBtnLogin")
	protected static WebElement loginButton;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idBtnRegister")
	protected static WebElement registerButton;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/tvNonLycaUser")
	protected static WebElement continueAsGuest;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'United Kingdom']")
	protected static WebElement selectUK;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idOtpEditText1")
	protected static WebElement otp1;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idOtpEditText2")
	protected static WebElement otp2;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idOtpEditText3")
	protected static WebElement otp3;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idOtpEditText4")
	protected static WebElement otp4;
	
	
	/**************************************************************************
	 * 		Methods for LoginPageObjects
	 * 
	 * ************************************************************************/
	
	public static void tapOnCountryDropDown() {
		selectCountryDropDown.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Clicked on country dropdown");
	}
	
	public static void selectCountry() {
		selectUK.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Selected UK as the country");
	}
	
	public static void tapOnContinueAsGuest() {
		continueAsGuest.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Clicked on 'Continue as Guest' button");
	}
	
	public static void loginWithExistingNumber() throws DOMException, SAXException, IOException, ParserConfigurationException {
		phoneNumberEditText.sendKeys(XMLReader.readFromXML(XMLReader.reader(readerCases.TEST_DATA), "contactNumber"));
		loginButton.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Logging in as an existing user");
	}
	
	public static void enterOTP() throws InterruptedException {
		Thread.sleep(4000);
		otp1.sendKeys("1");
		otp2.sendKeys("1");
		otp3.sendKeys("1");
		otp4.sendKeys("1");
		ExtentTestManager.getTest().log(LogStatus.INFO, "Passed the OTP");
	}
	
	public static void dismissLoginAlert() {
		
	}
	
	
}
