package com.lycadigital.pageObjects;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.lycadigital.genericUtils.XMLReader;
import com.lycadigital.genericUtils.ExtentReports.ExtentManager;
import com.lycadigital.genericUtils.ExtentReports.ExtentTestManager;
import com.lycadigital.testrunner.TestRunner;
import com.lycadigital.genericUtils.XMLReader.readerCases;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class PaymentPageObjects {

	public PaymentPageObjects(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	
	/**************************************************************************
	 * 		Initializing Page Objects for PaymentPageObjects
	 * 
	 * ************************************************************************/
	
	
	/*Credit Card Page Objects*/
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/edt_name_on_card")
	public static WebElement nameOnCard;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idCardNumberEdtTxt")
	public static WebElement cardNumber;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/edt_card_expiry_month")
	public static WebElement expiryMonth;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/edt_card_expiry_year")
	public static WebElement expiryYear;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/edt_card_cvv")
	public static WebElement cvv;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text = 'SecureCode™']")
	public static WebElement secureCode;
	
	@AndroidFindBy(xpath = "//android.widget.Button[@content-desc='Submit Submit']")
	public static WebElement submitButton;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'Saved cards']")
	public static WebElement savedCardsSection;
	
	/*Top Up Balance Page Objects*/
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/checkbox_select_main_bal")
	public static WebElement topUpBalanceCheckBox;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/tv_transaction_no")
	public static WebElement paymentSuccessfulMessage;
	
	/*Saved Credit Card Page Objects*/
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/edt_vvc_no")
	public static WebElement savedCardCVV;

	
	
	/**************************************************************************
	 * 		Methods for PaymentPageObjects
	 * 
	 * ************************************************************************/
	
	public static void fillCardDetails() throws DOMException, SAXException, IOException, ParserConfigurationException {
		
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element element = XMLReader.reader(readerCases.TEST_DATA);
		nameOnCard.sendKeys(XMLReader.readFromXML(element, "cardName"));
		cardNumber.sendKeys(XMLReader.readFromXML(element, "cardNumber"));
		expiryMonth.sendKeys(XMLReader.readFromXML(element, "expiryMonth"));
		expiryYear.sendKeys(XMLReader.readFromXML(element, "expiryYear"));
		cvv.sendKeys(XMLReader.readFromXML(element, "cvv"));
		
		ExtentTestManager.getTest().log(LogStatus.PASS, "Filled in Credit Card details");
	
	}
	
	public static void fillSavedCardDetails() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		savedCardsSection.click();
		ExtentTestManager.getTest().log(LogStatus.INFO, "Clicked on Saved Cards");
		
		savedCardCVV.sendKeys("652");
		ExtentTestManager.getTest().log(LogStatus.PASS, "Filled CVV details for saved card");
	}
	
	public static void fillSecureDetails() throws SAXException, IOException, ParserConfigurationException {
		Element element = XMLReader.reader(readerCases.TEST_DATA);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		secureCode.sendKeys(XMLReader.readFromXML(element, "secureCode"));
		submitButton.click();
		
		ExtentTestManager.getTest().log(LogStatus.PASS, "Submitted secure code");
	}
	
	public static void checkUseTopUpBalance() {
		topUpBalanceCheckBox.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Checked on Use Top Up balance checkbox");
	}
	
	public static void validatePaymentSuccessfulMessage() {
		TestRunner.softAssert.assertEquals(paymentSuccessfulMessage.getText(), "Bundle was successfully purchased");
		
		ExtentTestManager.getTest().log(LogStatus.PASS, "Validated Successful Transaction");
	}
	



}
