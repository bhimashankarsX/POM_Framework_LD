package com.lycadigital.pageObjects;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.hamcrest.CustomTypeSafeMatcher;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.context.annotation.ContextAnnotationAutowireCandidateResolver;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.lycadigital.driverengine.InstantiateAppium;
import com.lycadigital.genericUtils.CustomMethods;
import com.lycadigital.genericUtils.XMLReader;
import com.lycadigital.genericUtils.ExtentReports.ExtentTestManager;
import com.lycadigital.genericUtils.XMLReader.readerCases;
import com.lycadigital.testrunner.TestRunner;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumCommandInfo;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class UKBundlePageObjects extends CustomMethods{

	public UKBundlePageObjects(AppiumDriver driver) throws DOMException, SAXException, IOException, ParserConfigurationException, InterruptedException {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	
	}
	
	
	/**************************************************************************
	 * 		Initializing Page Objects for UKBundlePageObjects
	 * 
	 * ************************************************************************/
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/tv_cr_selBundleCat")
	public static WebElement selectBundleDropDown;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'All Bundles']")
	public static WebElement selectAllbundles;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text ='Data Bundles']")
	public static WebElement selectDataBundles;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text ='UK Plans']")
	public static WebElement selectUKPlans;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text ='Pay Monthly Plans']")
	public static WebElement selectPayMonthlyPlans;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text ='International Bundles']")
	public static WebElement selectInternationalBundles;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text ='Student Plans']")
	public static WebElement selectStudentPlans;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text ='All in One Bundles']")
	public static WebElement selectAllInOneBundles;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idAutoRechargeSwitch")
	public static WebElement autoRenewToggle;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text = 'World Plan X']")
	public static WebElement selectWorldPlanX;
	
	@AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id = 'com.lycadigital.lycamobile:id/tv_bundle_name'])[1]")
	public static WebElement worldPlanXElement;
	
	@AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id = 'com.lycadigital.lycamobile:id/tv_bundle_name'])[2]")
	public static WebElement data5Element;
	
	@AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id = 'com.lycadigital.lycamobile:id/tv_bundle_voice'])[1]")
	public static WebElement numInternationalMinutesPlanX;
	
	@AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id = 'com.lycadigital.lycamobile:id/tv_bundle_sms'])[1]")
	public static WebElement numNationalCallsPlanX;
	
	@AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id = 'com.lycadigital.lycamobile:id/tv_bundle_data'])[1]")
	public static WebElement numDataPlanX;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idEnterMobileNumber")
	public static WebElement phoneNumber;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/dialog_btn_ok")
	public static WebElement okButtonRecharge;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idContactImgView")
	public static WebElement contactButton;
	
	@AndroidFindBy(id = "com.android.contacts:id/menu_search")
	public static WebElement searchForContactButton;
	
	@AndroidFindBy(id = "android:id/search_src_text")
	public static WebElement searchForContactTV;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc= 'UKRecharge']")
	public static WebElement rechargeContact;
	
	
	
	
	/**************************************************************************
	 * 		Initializing Page Objects for UKBundlePageObjects
	 * 
	 * ************************************************************************/
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id = 'com.lycadigital.lycamobile:id/idBundlePlanName']")
	public static WebElement actualPlanName;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id = 'com.lycadigital.lycamobile:id/tv_bundle_details_mainvalue1']")
	public static WebElement actualNumInternationalMinutes;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id = 'com.lycadigital.lycamobile:id/tv_bundle_details_mainvalue2']")
	public static WebElement actualNumNationalCalls;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id = 'com.lycadigital.lycamobile:id/tv_bundle_details_mainvalue3']")
	public static WebElement actualNumData;
	
	@AndroidFindBy(xpath = "//android.widget.Button[@resource-id = 'com.lycadigital.lycamobile:id/idBundleDtlsSlctBtn']")
	public static WebElement buyNowButton;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idProceedToPayBtn")
	public static WebElement continueToBuyButton;
	

	
	
	
	/**************************************************************************
	 * 		Methods for UKBundleDetailsPageObject
	 * @throws InterruptedException 
	 * 
	 * ************************************************************************/
	
	
	
	public static void clickOnBundleDropDown() throws InterruptedException {
		Thread.sleep(5000);
		selectBundleDropDown.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Clicked on Bundle Dropdown");
	}
	
	public static String getCONTACT_NAME(Element element) throws DOMException, SAXException, IOException, ParserConfigurationException {
		element = XMLReader.reader(readerCases.TEST_DATA);
		String CONTACT_NAME = element.getElementsByTagName("contactName").item(0).getTextContent();
		ExtentTestManager.getTest().log(LogStatus.INFO, "Read contact name for recharge from XML input");
		return CONTACT_NAME;
	}
	
	public static enum availableBundlesForUK{
		ALL_BUNDLES,
		DATA_BUNDLES,
		UK_PLANS,
		PAY_MONTHLY_PLANS,
		INTERNATIONAL_BUNDLES,
		STUDENT_PLANS,
		ALL_IN_ONE_BUNDLES;
	}
	
	
	public static void selectBundle(availableBundlesForUK bundles) {
		switch(bundles) {
		case ALL_BUNDLES:
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			selectAllbundles.click();
			ExtentTestManager.getTest().log(LogStatus.PASS, "Selected 'ALL BUNDLES'");
			break;
		case DATA_BUNDLES:
			selectDataBundles.click();
			ExtentTestManager.getTest().log(LogStatus.PASS, "Selected 'DATA BUNDLES'");
			break;
		case UK_PLANS:
			selectUKPlans.click();
			ExtentTestManager.getTest().log(LogStatus.PASS, "Selected 'UK PLANS'");
			break;
		case PAY_MONTHLY_PLANS:
			selectPayMonthlyPlans.click();
			ExtentTestManager.getTest().log(LogStatus.PASS, "Selected 'PAY MONTHLY PLANS'");
			break;
		case INTERNATIONAL_BUNDLES:
			selectInternationalBundles.click();
			ExtentTestManager.getTest().log(LogStatus.PASS, "Selected 'INTERNATIONAL BUNDLES'");
			break;
		case STUDENT_PLANS:
			selectStudentPlans.click();
			ExtentTestManager.getTest().log(LogStatus.PASS, "Selected 'STUDENT PLANS'");
			break;
		case ALL_IN_ONE_BUNDLES:
			selectAllInOneBundles.click();
			ExtentTestManager.getTest().log(LogStatus.PASS, "Selected 'ALL IN ONE BUNDLES'");
			break;
		}
	  }
	
	public static ArrayList<String> fetchPlanDetailsFromBundlePage() {
		ArrayList<String> planDetails = new ArrayList<String>();
		
 		String planName = worldPlanXElement.getText();
		String numMinutes   = numInternationalMinutesPlanX.getText();
		String numNationalCalls = numNationalCallsPlanX.getText();
		String numData = numDataPlanX.getText();
		
		planDetails.add(planName);
		planDetails.add(numMinutes);
		planDetails.add(numNationalCalls);
		planDetails.add(numData);
		return planDetails;
	}
	
	public static ArrayList<String> fetchPlanDetailsExpanded(){
		ArrayList<String> actualPlanDetails = new ArrayList<String>();
		
		String actualPlanName = worldPlanXElement.getText();
		String actualNumMinutes   = numInternationalMinutesPlanX.getText();
		String actualNumNationalCalls = numNationalCallsPlanX.getText();
		String actualNumData = numDataPlanX.getText();
		
		actualPlanDetails.add(actualPlanName);
		actualPlanDetails.add(actualNumMinutes);
		actualPlanDetails.add(actualNumNationalCalls);
		actualPlanDetails.add(actualNumData);
		return actualPlanDetails;
		
	}
	
	public static void clickOnAutoRenewToggleButton() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		autoRenewToggle.click();
	}
	
	public static void clickOnWorldPlanX() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		selectWorldPlanX.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Clicked on 'Select World Plan X' button");
	}
	
	public static void clickOnData5() {
		data5Element.click();
		ExtentTestManager.getTest().log(LogStatus.INFO, "Selected Data 5");
	}
	
	public static void clickOnBuyNow() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		buyNowButton.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Clicked on 'Buy Now' button");
	}
	
	
	public static void selectContactForRecharge() throws DOMException, SAXException, IOException, ParserConfigurationException, InterruptedException {
		contactButton.click();
		TestRunner.allowPermission();
		//TAP_ON_ELEMENT(searchForContactButton);
		ExtentTestManager.getTest().log(LogStatus.INFO, "Android - Granted permissions");
		searchForContactButton.click();
		searchForContactTV.sendKeys(getCONTACT_NAME(XMLReader.reader(readerCases.TEST_DATA)));
		rechargeContact.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Fetched contact name for recharge from contacts");
		
	}
	
	public static void clickOnOkButtonRecharge() {
		okButtonRecharge.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Clicked on 'OK' button");
	}
	
	public static void clickOnOrderConfirmationContinue() throws DOMException, SAXException, IOException, ParserConfigurationException, InterruptedException {
		Thread.sleep(3000);
		continueToBuyButton.click();
		ExtentTestManager.getTest().log(LogStatus.PASS, "Continuing with transaction");
	}
	
	
	
}
