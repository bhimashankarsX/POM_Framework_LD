package com.lycadigital.pageObjects;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.DOMException;
import org.xml.sax.SAXException;

import com.lycadigital.programUtils.GeneralFunctions;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class DashboardPageObjects {
	
	static WebDriverWait wait;

	@SuppressWarnings("rawtypes")
	public DashboardPageObjects(AppiumDriver driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	/**************************************************************************
	 * 		Initializing Page Objects for DashboardPageObjects
	 * 
	 * ************************************************************************/
	@AndroidFindBy(id="com.lycadigital.lycamobile:id/bundle_topup_desc_text")
	public static WebElement accountBalanceLow;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idbuyBundlebtn")
	public static WebElement buyBundleLoggedIn;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idQuickTopupBtn")
	public static WebElement topUpLoggedIn;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idTopupBottomTab")
	public static WebElement topUpBottomLoggedIn;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idBundlesBottomBar")
	public static WebElement bundlesBottomLoggedIn;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idCallRatesBottomTab")
	public static WebElement checkRatesBottomLoggedIn;
	
	@AndroidFindBy(id = "com.lycadigital.lycamobile:id/idHistoryBottomTab")
	public static WebElement transactionHistoryLoggedIn;
		
	/**************************************************************************
	 * 		Methods for DashboardPageObjects
	 * @throws InterruptedException 
	 * 
	 * ************************************************************************/
	

	public static void clickOnBuyBundleLoggedIn(){
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//wait.until(ExpectedConditions.visibilityOf(buyBundleLoggedIn));
		buyBundleLoggedIn.click();
	}
	
	public static void clickOnTopUpLoggedIn() {
		topUpLoggedIn.click();
	}

	public static void clickOnTopUpBottomLoggedIn() {
		topUpBottomLoggedIn.click();
	}
	
	public static void clickOnBundlesBottomLoggedIn() {
		bundlesBottomLoggedIn.click();
	}
	
	public static void clickOnCheckRatesBottonLoggedIn() {
		checkRatesBottomLoggedIn.click();
	}
	
	public static void clickOnTransactionHistoryLoggedIn() {
		transactionHistoryLoggedIn.click();
	}
}
