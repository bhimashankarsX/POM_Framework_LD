package com.lycadigital.testrunner.OtherUser;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.testng.annotations.Test;
import org.w3c.dom.DOMException;
import org.xml.sax.SAXException;

import com.lycadigital.genericUtils.ExtentReports.ExtentManager;
import com.lycadigital.genericUtils.ExtentReports.ExtentTestManager;
import com.lycadigital.pageObjects.BillingAddressPageObjects;
import com.lycadigital.pageObjects.LoggedInAsOtherUserPageObjects;
import com.lycadigital.pageObjects.PaymentPageObjects;
import com.lycadigital.pageObjects.UKBundlePageObjects;
import com.lycadigital.pageObjects.UKBundlePageObjects.availableBundlesForUK;
import com.lycadigital.testrunner.AppInitialization;
import com.lycadigital.testrunner.TestRunner;
import com.relevantcodes.extentreports.LogStatus;

public class UKBundleOtherUserTest extends TestRunner{

	@SuppressWarnings("static-access")
	@Test(priority = 0)
	public static void PAYMENT_BUNDLE_SUCCESS_SCENARIO_OTHER_USER() throws DOMException, SAXException, IOException, ParserConfigurationException, InterruptedException {
		
		/**************************************************************************
		 * 	Initialize all page objects to be used for UKBundleDetailsPageObjectTest
		 * 
		 * ************************************************************************/
		
		UKBundlePageObjects ukBundlePageObjects = new UKBundlePageObjects(driver);
		LoggedInAsOtherUserPageObjects loggedInAsOtherUserPageObjects = new LoggedInAsOtherUserPageObjects(driver);
		PaymentPageObjects paymentPageObjects = new PaymentPageObjects(driver);
		BillingAddressPageObjects billingAddressPageObjects = new BillingAddressPageObjects(driver);
		
		
		/**************************************************************************
		 * 		Methods for UKBundleDetailsPageObjectTest
		 * 
		 * ************************************************************************/
		
		AppInitialization.INITIAL_SWIPES_CLICK_ON_GET_STARTED();
		AppInitialization.SELECT_COUNTRY_CONTINUE_AS_GUEST();
		loggedInAsOtherUserPageObjects.tapOnBundles();
		ukBundlePageObjects.clickOnBundleDropDown();
		ukBundlePageObjects.selectBundle(availableBundlesForUK.ALL_BUNDLES);
		ukBundlePageObjects.clickOnWorldPlanX();
		ukBundlePageObjects.clickOnBuyNow();
		ukBundlePageObjects.selectContactForRecharge();
		ukBundlePageObjects.clickOnOkButtonRecharge();
		ukBundlePageObjects.clickOnOrderConfirmationContinue();
		paymentPageObjects.fillCardDetails();
		ukBundlePageObjects.clickOnOrderConfirmationContinue();
		billingAddressPageObjects.fillPaymentForm();
		ukBundlePageObjects.clickOnOrderConfirmationContinue();
		paymentPageObjects.fillSecureDetails();
		
		
		
		
		
		
	}
}
