package com.lycadigital.testrunner;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.testng.annotations.Test;
import org.w3c.dom.DOMException;
import org.xml.sax.SAXException;

import com.lycadigital.genericUtils.ExtentReports.ExtentTestManager;
import com.lycadigital.pageObjects.*;
import com.lycadigital.programUtils.*;
import com.lycadigital.programUtils.GeneralFunctions.swipeType;
import com.relevantcodes.extentreports.LogStatus;

public class AppInitialization extends TestRunner {
	
	static LoginPageObjects loginPage = new LoginPageObjects(driver);
	
	@SuppressWarnings("static-access")
	public static void INITIAL_SWIPES_CLICK_ON_GET_STARTED() throws InterruptedException, DOMException, SAXException, IOException, ParserConfigurationException {
		GeneralFunctions.swipe(driver, swipeType.LEFT, 1);
		GeneralFunctions.swipe(driver, swipeType.LEFT, 1);
		GeneralFunctions.swipe(driver, swipeType.LEFT, 1);
		ExtentTestManager.getTest().log(LogStatus.PASS, "Swiped till 'Get Started' button");
		GetStartedPageObjects getStarted = new GetStartedPageObjects(driver);
		AndroidNativeAlertHandler androidNativeAlertHandler = new AndroidNativeAlertHandler(driver);
		getStarted.tapOnGetStarted();
		Thread.sleep(4000);
		allowPermission();
	
	}
	
	@SuppressWarnings("static-access")
	public static void SELECT_COUNTRY_CONTINUE_AS_GUEST() throws InterruptedException {
		Thread.sleep(3000);
		loginPage.tapOnCountryDropDown();
		Thread.sleep(4000);
		loginPage.selectCountry();

	}

	@SuppressWarnings("static-access")
	public static void SELECT_COUNTRY_LOG_IN() throws InterruptedException, DOMException, SAXException, IOException, ParserConfigurationException {
		loginPage.tapOnCountryDropDown();
		Thread.sleep(3000);
		loginPage.selectCountry();
		Thread.sleep(3000);
		loginPage.loginWithExistingNumber();
		Thread.sleep(3000);
		loginPage.enterOTP();
		Thread.sleep(4000);
	}
	
	
}
