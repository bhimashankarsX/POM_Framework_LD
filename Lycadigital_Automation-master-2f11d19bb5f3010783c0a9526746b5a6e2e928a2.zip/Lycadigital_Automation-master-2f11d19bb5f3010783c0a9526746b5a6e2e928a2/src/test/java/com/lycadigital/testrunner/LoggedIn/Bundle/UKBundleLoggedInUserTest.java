package com.lycadigital.testrunner.LoggedIn.Bundle;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.testng.annotations.Test;
import org.w3c.dom.DOMException;
import org.xml.sax.SAXException;

import com.lycadigital.pageObjects.BillingAddressPageObjects;
import com.lycadigital.pageObjects.DashboardPageObjects;
import com.lycadigital.pageObjects.LoggedInAsOtherUserPageObjects;
import com.lycadigital.pageObjects.PaymentPageObjects;
import com.lycadigital.pageObjects.UKBundlePageObjects;
import com.lycadigital.pageObjects.UKBundlePageObjects.availableBundlesForUK;
import com.lycadigital.testrunner.AppInitialization;
import com.lycadigital.testrunner.TestRunner;

public class UKBundleLoggedInUserTest extends TestRunner{


		@SuppressWarnings("static-access")
		@Test(priority = 0)
		public static void BUNDLE_LOGGED_IN_AUTO_RENEW_OFF_CC_SUCCESS() throws DOMException, SAXException, IOException, ParserConfigurationException, InterruptedException {
			
			/**************************************************************************
			 * 	Initialize all page objects to be used for UKBundleDetailsPageObjectTest
			 * 
			 * ************************************************************************/
			
			UKBundlePageObjects ukBundlePageObjects = new UKBundlePageObjects(driver);
			LoggedInAsOtherUserPageObjects loggedInAsOtherUserPageObjects = new LoggedInAsOtherUserPageObjects(driver);
			PaymentPageObjects paymentPageObjects = new PaymentPageObjects(driver);
			BillingAddressPageObjects billingAddressPageObjects = new BillingAddressPageObjects(driver);
			DashboardPageObjects dashboardPageObjects = new DashboardPageObjects(driver);
			
			
			/**************************************************************************
			 * 		Methods for UKBundleDetailsPageObjectTest
			 * 
			 * ************************************************************************/
			
			AppInitialization.INITIAL_SWIPES_CLICK_ON_GET_STARTED();
			AppInitialization.SELECT_COUNTRY_LOG_IN();
			dashboardPageObjects.clickOnBuyBundleLoggedIn();
			ukBundlePageObjects.clickOnBundleDropDown();
			ukBundlePageObjects.selectBundle(availableBundlesForUK.ALL_BUNDLES);
			ukBundlePageObjects.clickOnWorldPlanX();
			ukBundlePageObjects.clickOnAutoRenewToggleButton();
			ukBundlePageObjects.clickOnBuyNow();
			ukBundlePageObjects.clickOnOrderConfirmationContinue();
			paymentPageObjects.fillCardDetails();
			ukBundlePageObjects.clickOnOrderConfirmationContinue();
			Thread.sleep(5000);
			ukBundlePageObjects.clickOnOrderConfirmationContinue();
			paymentPageObjects.fillSecureDetails();

		}
		
		@SuppressWarnings("static-access")
		@Test(priority = 1)
		public static void BUNDLE_LOGGED_IN_AUTO_RENEW_OFF_TOPUP_BALANCE_SUCCESS() throws DOMException, SAXException, IOException, ParserConfigurationException, InterruptedException {
			
			/**************************************************************************
			 * 	Initialize all page objects to be used for UKBundleDetailsPageObjectTest
			 * 
			 * ************************************************************************/
			
			UKBundlePageObjects ukBundlePageObjects = new UKBundlePageObjects(driver);
			LoggedInAsOtherUserPageObjects loggedInAsOtherUserPageObjects = new LoggedInAsOtherUserPageObjects(driver);
			PaymentPageObjects paymentPageObjects = new PaymentPageObjects(driver);
			BillingAddressPageObjects billingAddressPageObjects = new BillingAddressPageObjects(driver);
			DashboardPageObjects dashboardPageObjects = new DashboardPageObjects(driver);
			
			
			/**************************************************************************
			 * 		Methods for UKBundleDetailsPageObjectTest
			 * 
			 * ************************************************************************/
			
			AppInitialization.INITIAL_SWIPES_CLICK_ON_GET_STARTED();
			AppInitialization.SELECT_COUNTRY_LOG_IN();
			dashboardPageObjects.clickOnBuyBundleLoggedIn();
			ukBundlePageObjects.clickOnBundleDropDown();
			ukBundlePageObjects.selectBundle(availableBundlesForUK.ALL_BUNDLES);
			ukBundlePageObjects.clickOnWorldPlanX();
			ukBundlePageObjects.clickOnAutoRenewToggleButton();
			ukBundlePageObjects.clickOnBuyNow();
			ukBundlePageObjects.clickOnOrderConfirmationContinue();
			paymentPageObjects.checkUseTopUpBalance();
			ukBundlePageObjects.clickOnOrderConfirmationContinue();
			Thread.sleep(5000);
			ukBundlePageObjects.clickOnOrderConfirmationContinue();
			paymentPageObjects.validatePaymentSuccessfulMessage();
	
			
		}
		
		@SuppressWarnings("static-access")
		@Test(priority = 1)
		public static void BUNDLE_LOGGED_IN_AUTO_RENEW_OFF_SAVED_CARD_SUCCESS() throws DOMException, SAXException, IOException, ParserConfigurationException, InterruptedException {
			
			/**************************************************************************
			 * 	Initialize all page objects to be used for UKBundleDetailsPageObjectTest
			 * 
			 * ************************************************************************/
			
			UKBundlePageObjects ukBundlePageObjects = new UKBundlePageObjects(driver);
			LoggedInAsOtherUserPageObjects loggedInAsOtherUserPageObjects = new LoggedInAsOtherUserPageObjects(driver);
			PaymentPageObjects paymentPageObjects = new PaymentPageObjects(driver);
			BillingAddressPageObjects billingAddressPageObjects = new BillingAddressPageObjects(driver);
			DashboardPageObjects dashboardPageObjects = new DashboardPageObjects(driver);
			
			
			/**************************************************************************
			 * 		Methods for UKBundleDetailsPageObjectTest
			 * 
			 * ************************************************************************/
			
			AppInitialization.INITIAL_SWIPES_CLICK_ON_GET_STARTED();
			AppInitialization.SELECT_COUNTRY_LOG_IN();
			dashboardPageObjects.clickOnBuyBundleLoggedIn();
			ukBundlePageObjects.clickOnBundleDropDown();
			ukBundlePageObjects.selectBundle(availableBundlesForUK.ALL_BUNDLES);
			ukBundlePageObjects.clickOnWorldPlanX();
			ukBundlePageObjects.clickOnAutoRenewToggleButton();
			ukBundlePageObjects.clickOnBuyNow();
			ukBundlePageObjects.clickOnOrderConfirmationContinue();
			paymentPageObjects.fillSavedCardDetails();
			ukBundlePageObjects.clickOnOrderConfirmationContinue();
			Thread.sleep(5000);
			ukBundlePageObjects.clickOnOrderConfirmationContinue();
			paymentPageObjects.fillSecureDetails();
	
			
		}
}
