package com.lycadigital.exp;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.lycadigital.genericUtils.XMLReader;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
	

public class Trial {
	
	public static void swipe(AppiumDriver drvr){
		TouchAction swipeAction = new TouchAction(drvr);
		Dimension size = drvr.manage().window().getSize();
		System.out.println(size);
		int startX = (int)(size.width*0.80);
		int startY = (int)(size.height*0.50);
		int endX = (int)(size.width*0.10);
		int endY = 0;
		System.out.println("Swiping with: " + startX  + " " + startY + " " + endX + " " + endY);
		swipeAction.press(startX, startY).waitAction().moveTo(-endX, endY).release().perform();
	}

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		
		DesiredCapabilities appiumCapabilities = new DesiredCapabilities();
		appiumCapabilities.setCapability("deviceName","emulator-5554");
		appiumCapabilities.setCapability("platformName","Android");
		appiumCapabilities.setCapability("platformVersion","8.1.0");
		appiumCapabilities.setCapability("appPackage","com.lycadigital.lycamobile");
		appiumCapabilities.setCapability("appActivity","com.lycadigital.lycamobile.view.SplashScreen");
		appiumCapabilities.setCapability("automationName","uiautomator2");
		appiumCapabilities.setCapability(MobileCapabilityType.APP,System.getProperty("user.dir")+"/Resources/apk/LycaMobile.apk");
		appiumCapabilities.setCapability("noReset", false);
		
		AppiumServiceBuilder builder = new AppiumServiceBuilder()
				.withAppiumJS(new File("C:/Users/bhima.shankar/AppData/Roaming/npm/node_modules/appium/build/lib/main.js"));
	
		AppiumDriverLocalService appiumService = builder.build();
		appiumService.start();
		String appiumServiceURL = appiumService.getUrl().toString();
		AppiumDriver appiumDriverInstance = new AppiumDriver(new URL(appiumServiceURL), appiumCapabilities);
			appiumDriverInstance.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			
			TouchAction swipeAction = new TouchAction(appiumDriverInstance);
			Thread.sleep(3000);
			
			
			
			
		/*	 JavascriptExecutor js = (JavascriptExecutor) appiumDriverInstance;
	            HashMap<String, String> swipeObject = new HashMap<String, String>();
	            swipeObject.put("direction", "left");*/
			
			
			Dimension size = appiumDriverInstance.manage().window().getSize();
			System.out.println(size);
			int startX = (int)(size.width*0.80);
			int startY = (int)(size.height*0.50);
			int endX = (int)(size.width*0.10);
			int endY = 0;
			swipeAction.longPress(startX, startY).waitAction().moveTo(endX*-1,0).release().perform();
			swipeAction.longPress(startX, startY).waitAction().moveTo(endX*-1,0).release().perform();
			swipeAction.longPress(startX, startY).waitAction().moveTo(endX*-1,0).release().perform();
			swipeAction.longPress(startX, startY).waitAction().moveTo(endX*-1,0).release().perform();
			System.out.println("swiped on the screen");
			System.out.println("The End");
			
		/*	swipe(appiumDriverInstance);
			swipe(appiumDriverInstance);
			swipe(appiumDriverInstance);
			swipe(appiumDriverInstance);*/
	}

}
